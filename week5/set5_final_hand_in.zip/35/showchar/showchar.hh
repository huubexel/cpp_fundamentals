#ifndef INCLUDED_SHOWCHAR_
#define INCLUDED_SHOWCHAR_

void showChar(char const &ch);    // showChar function declaration

#endif
