#include "charcount.ih"

CharCount::CharInfo const &CharCount::info() const
{
    return d_charInfo;
}
